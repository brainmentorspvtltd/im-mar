function add(){
    let id = document.querySelector('#id').value;
    let name = document.querySelector('#name').value;
    let cost = document.querySelector('#cost').value;
    let date = document.querySelector('#date').value;
    let remarks = document.querySelector('#remarks').value;
    let url = document.querySelector('#url').value;
    const expenseObject = {
        id, name, cost, date, remarks, url
    }
    console.log("I am add ", expenseObject);
}