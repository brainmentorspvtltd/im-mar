import React from 'react'

export const  Itemslist=(props)=> {


    return (
        <>
            {props.items.length}
        </>
    )
}
