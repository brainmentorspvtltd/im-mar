import React, { useRef , useEffect} from 'react'


export const  SearchInput=React.memo((props) =>{
   // export const SearchInput = (props)=>{
       let x,y;
    useEffect(()=>{
        console.log("::::Component Did Mount Happens....");
        console.log('::::Did Update Call');
    });  // for all values
   useEffect(()=>{
        console.log("::::Component Did Mount Happens....");

    },[]);
    useEffect(()=>{
        console.log("::::Component Did Mount Happens....");
        console.log('::::Did Update Call');
    },[x,y]); // for only x and y updation
    const searchTxtBox = useRef(0);
    const takeSearchValue = (evt)=>{
        let txtBoxValue = searchTxtBox.current.value;
        //let txtBoxValue = evt.target.value;
        props.input(txtBoxValue);
        console.log('Txt Box Value is ',txtBoxValue, ' ');
    }
    // ref={searchTxtBox}
    console.log('Props ',props.val);
    return (
        <div className='form-group'>

             {/* for useEffect - DidUpdate <input onChange={takeSearchValue} value={props.val}  className='form-control' type='text' placeholder='Type to Search'/> */}
             <input    className='form-control' type='text' placeholder='Type to Search'/>
             <button onClick={takeSearchValue} className = 'btn btn-primary'>Search</button>
        </div>
    );
});
//);
