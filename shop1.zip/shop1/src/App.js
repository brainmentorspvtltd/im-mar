import logo from './logo.svg';
import './App.css';
import { SearchPage } from './containers/SearchPage';

function App() {
  return (
    <SearchPage/>
  );
}

export default App;
