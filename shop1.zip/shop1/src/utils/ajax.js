import { CONFIG } from "./config"

export const fetchItems = ()=>{
    const promise = fetch(CONFIG.ITEMS_URL);
    return promise;
}