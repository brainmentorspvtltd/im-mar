import React from 'react';
export const Header = ()=>{
    return (<div>
        <h3>I am a Header</h3>
    </div>)
}