import React from 'react';
import './App.css';
import { Header } from './components/Header';
 function App(){
   const myStyle = {
     backgroundColor:'green',
     color:'yellow'
   };
  //return React.createElement('h1',null,'Hello ReactJS');
  //return React.createElement('div',null,
 // React.createElement('h1', null,'Hello React JS'),
 // React.createElement('h2',null, 'Hi React JS '));
  //return React.createElement('h1',null,'Hello ReactJS')
  //, React.createElement('h2',null, 'Hi React JS ');
  var name = "Amit";
  return (<div>
    <Header/>
    <h1 className='red'>Hello React JS in JSX Style {name}</h1>
  <h2 style={myStyle}>Hi ReactJS</h2>

  </div>);
  // <h1 >Hello ReactJS </h1>
  //
}
export default App;