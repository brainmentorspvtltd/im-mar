
import { useState } from 'react';
import { Route, Switch } from 'react-router';
import './App.css';
import { Aboutus } from './components/AboutUs';
import { Header } from './components/Header';
import { Home } from './components/Home';
import { SearchPage } from './containers/SearchPage';
import { ItemContext } from './utils/context';

let total = 0;
const App=()=> {
  console.log('App Render Call Again');

  const [tot, setTotal] =useState(0);
  const updateTotal=(currentPlus)=>{
    total += currentPlus;
    setTotal(total);
    console.log('After Updation in Total ',total);
  }
  return(
    <>
    <Header/>
    <Switch>
      <Route exact path="/" component={Home}/>
      <Route exact path="/search" component={SearchPage}/>
      <Route exact path="/about" component={Aboutus}/>
    </Switch>
    </>
  )
  /*
  return (
    <ItemContext.Provider value={{totalInCart:total, updateTotal:updateTotal}}>
    <SearchPage/>
    </ItemContext.Provider>
  );*/
}

export default App;
