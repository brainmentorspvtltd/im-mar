export const itemReducer = (state = {total:0}, action)=>{
    if(action.type=='ADD'){
        // new state
        return {total: state.total + action.payload.currentValue}
    }
    else
    if(action.type=='REMOVE'){
        return {total: state.total + action.payload.currentValue}
    }
    return state; // old state
}