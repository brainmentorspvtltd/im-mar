import React from 'react';
export const ItemContext = React.
createContext({totalInCart:0, updateTotal:function(){}});