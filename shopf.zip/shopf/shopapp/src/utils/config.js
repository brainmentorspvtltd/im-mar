export const CONFIG ={
    //ITEMS_URL:'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/mobiles.json'
    ITEMS_URL:'http://localhost:9797/products'
}