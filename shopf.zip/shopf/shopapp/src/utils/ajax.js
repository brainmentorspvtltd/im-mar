import { CONFIG } from "./config"
import axios from 'axios';
export const interceptors = ()=>{
    axios.interceptors.request.use((request)=>{
        //request.tokenId = localStorage.tokenId;
        request.tokenId = 'ABC123';
        console.log('Intercept Happens');
        return request;
    },(err)=>{
        console.log("not able to register")
    })
}
export const fetchItems = ()=>{
    //const promise = fetch(CONFIG.ITEMS_URL);
    console.log('Ajax Call');
    const promise = axios.get(CONFIG.ITEMS_URL);
    return promise;
}