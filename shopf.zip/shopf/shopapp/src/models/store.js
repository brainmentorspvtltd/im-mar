import {createStore} from 'redux';
import { itemReducer } from '../helpers/itemreducer';
export const store = createStore(itemReducer);
const state = store.subscribe(()=>{
    console.log('Store / State Updated....', state)
})