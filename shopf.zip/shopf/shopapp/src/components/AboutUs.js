import React from 'react'

export const  Aboutus=(props)=> {


    return (
        <>
                <h2 className="alert-warning">About Us Section</h2>
        </>
    )
}
