import React from 'react'
import { Item } from './Item'

export const  Itemslist=(props)=> {

    //{props.items.length}
    return (
        <>

          {props.items.map((item,index)=><Item key={item.id} item={item}/>)}
        </>
    )
}
