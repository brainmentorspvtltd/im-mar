import React from 'react'
import {ItemContext} from '../../utils/context';
import {connect} from 'react-redux';
export const  Carttotal=(props) =>{

    return (
        <p>Total Items in Cart {props.cartTotal}</p>
    )
   /* return (
        <>
        <ItemContext.Consumer>
        {
            (context)=><p>Total Items in Cart {context.totalInCart} </p>
        }
        </ItemContext.Consumer>

        </>
    )*/
}

const mapStateToProps = (state)=>{
    return {
        cartTotal:state.total
    }
}

export default connect(mapStateToProps)(Carttotal);
