const fs = require('fs');
function isStaticContent(url){
    const extensions = ['.html','.css','.js','.png','.jpeg','.jpg'];
    if(url=='/'){
        url = '/index.html';
    }
    const path = require('path');
    const parentPath = path.normalize(__dirname+'/..');
    const fullPath = path.join(parentPath,'/public'+url);
    let ext = path.extname(fullPath);
    let index = extensions.indexOf(ext);
    return index>=0;

}
 function readStaticContent(name, response){

    const path = require('path');
    const parentPath = path.normalize(__dirname+'/..');
    const fullPath = path.join(parentPath,'/public'+name);

    //console.log(fullPath);
    fs.readFile(fullPath, (err, content)=>{
        if(err){
            response.write('404 File not found...');
        }
        else{
            response.write(content);
        }
        response.end();
    })
    //console.log(__dirname);
}
module.exports = {
    isStaticContent, readStaticContent
}