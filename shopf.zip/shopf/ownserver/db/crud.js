var mysql      = require('mysql');

const dbOperations = {
    dbConnection(){
        var connection = mysql.createConnection({
            host     : 'localhost',
            user     : 'root',
            password : 'amit123456',
            database : 'im_db'
          });

          connection.connect();
          return connection;
    },
     fetchItems(){

        let connection = this.dbConnection();

        let promise = new Promise((resolve, reject)=>{
            connection.query('select id, name, price, url from item', function (error, results, fields) {
                if (error) reject(error);
                resolve(results);
               // results.forEach(ele=>console.log(ele));
                //console.log('The solution is: ', results);
              });
              connection.end();
        });
        return promise;

    }
}

module.exports = dbOperations;



// var promise = dbOperations.fetchItems();
// promise.then(data=>{
//     console.log(data);
// }).catch(err=>console.log(err));


