const http = require('http');
const chalk  = require('chalk');
const staticContent = require('./utils/read');

function setHeaders(res){
    res.setHeader('Access-Control-Allow-Origin', '*');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

}

const server = http.createServer((request, response)=>{
    console.log('Rec Req ', request.url);
    let url = request.url;

    if(staticContent.isStaticContent(url)){
        staticContent.readStaticContent(url=='/'?'/index.html':url,response);
    }
    else
    if(url=='/products' && request.method=='GET')
    {
        setHeaders(response);
       const dbOperations =  require('./db/crud');
        dbOperations.fetchItems().then(items=>{
        let map = {"mobiles":items};
       response.write(JSON.stringify(map));
       response.end();
       }).catch(err=>{
        response.write('DB Error ');
        response.end();
       });

        // not static content
    }
    // if(request.url=='/' || request.url =='/index.html'){
    //     url = '/index.html';
    //     readStaticContent(url, response);
    // }
    // else{
    //     response.write('Hello User...');
    //     response.end();
    // }


});
server.listen(process.env.PORT || 9797,()=>{
    console.log(chalk.green('Server Started...'), server.address().port)
})