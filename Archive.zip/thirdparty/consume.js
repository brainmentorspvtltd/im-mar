const chalk = require('chalk');
console.log(chalk.red('Hello'));
console.log(chalk.green('green style'));
console.log(chalk.bold.red('Hi'));
//const obj = require('otplib');
const {authenticator} = require('otplib');
const token = authenticator.generate('THISISMYSECRETKEY');
console.log(token);