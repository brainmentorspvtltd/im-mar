const fs = require('fs'); // fs file system
//console.log(__filename);
//console.log(__dirname);
console.log('Before read...');
fs.writeFile('xyz.txt',"hsdjkgdfghdgkj",(err)=>{
    console.log(err?err:'Write Done...');
})

//fs.writeFileSync
//fs.writeFile
//fs.appendFile
//fs.copyFile
//fs.unlink
//fs.mkdir
//fs.rmdir
try{
let c = fs.readFileSync(__filename); // Sync (Blocked)
console.log(c.toString());
}
catch(e){
    console.log(e);
}
console.log('Sync Read is DONE........');
fs.readFile(__filename, (error, content)=>{
    if(error){
        console.log('Unable to read the file ',error);
    }
    else{
        console.log(content.toString());
    }
}) // async

fs.readFile('/Users/amit/Documents/react-app-codes/nodedemos/four.js', (error, content)=>{
    if(error){
        console.log('Unable to read the file ',error);
    }
    else{
        console.log(content.toString());
    }
})
console.log('After Read');
for(let i = 1;i<=10; i++){
    console.log('Loop ',i);
}