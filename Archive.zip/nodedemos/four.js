process.on('uncaughtException',(err)=>{
    console.log('Caught It ',err);
})
console.log(process.versions.v8);
console.log(process.arch);
console.log(process.cpuUsage());
console.log(process.memoryUsage());
process.stdout.write('Write....');
console.log(process.env.LOGNAME);
let env = process.argv[2];
ppp++;

const config = require('./config');
let configuration = config[env];
console.log(configuration);
