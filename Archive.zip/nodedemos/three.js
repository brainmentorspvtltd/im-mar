module.exports = {
    add(a=0, b=0){ // add : function (Es6 Object ShortHand)
        return a + b;
    },
    sub(a=0, b= 0){
        return a - b;
    }

}