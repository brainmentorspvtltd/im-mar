module.exports = {
    DEV :{
        DB:'LOCAL DB URL',
        MAIL : 'LOCAL MAIL URL'
    },
    PROD :{
        DB :'AWS DB URL',
        MAIL :'AWS MAIL SERVICE URL'
    }
}