//const object = require('./one'); // u get an object because u export the object
const object = require('./three');
console.log(object);
console.log(typeof object);
//var c = object.addition(10,20);
let c = object.add(10,20);
console.log(c);