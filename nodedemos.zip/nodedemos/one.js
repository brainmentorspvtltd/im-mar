// var a= 100;
// var b = 200;
// var c = 300;
// c = a + b;
// console.log(c);
function add(a=0, b=0){
    var c = a + b;
    return c;
}
function sub(a=0, b=0){
    return a - b;
}
//      {}    = function;
//module.exports = add; // assign a function in exports and it become function type
console.log(module.exports); // {}
console.log(typeof module.exports); // object
module.exports.addition = add; // fill up the object with key and value
module.exports.sub = sub; // fill up
// {addition:add, sub : sub} u export the object contain key and value
