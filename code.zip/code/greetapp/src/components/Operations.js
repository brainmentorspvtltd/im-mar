import React from 'react'

export  const Operations=(props)=> {


    return (
        <button onClick={props.opr} className ={props.styling}>{props.label}</button>
    )
}
