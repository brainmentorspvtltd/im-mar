import React from 'react'

export const  Message=(props)=> {


    return (
        <>
          <h2> {props.message}</h2>
        </>
    )
}
