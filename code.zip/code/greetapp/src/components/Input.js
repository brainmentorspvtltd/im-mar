import React from 'react'

// var props = {title : 'First Name', takeinput: takeFirstName/takeLastName}
export  const Input=(props) =>{
    const placeHolder = `Type ${props.title}  Here`;
    let firstName  =''; // local (Not to be Share)


    return (
        <div className = 'form-group'>
           <label>{props.title}</label>
           <input onChange={props.takeinput} className = 'form-control' type='text'
            placeholder={placeHolder}/>
        </div>
    )
}

// 10 , 20 - wrap all args in a object
function add(obj){
    return obj.a + obj.b;
}

add({a:10, b:20, c:30});
add(20,40);