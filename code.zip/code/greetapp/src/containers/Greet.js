import React, {Component} from 'react'
import { Input } from '../components/Input'
import { Message } from '../components/Message';
import { Operations } from '../components/Operations'
import { Title } from '../components/Title'


class Greet extends Component {
    constructor(){
        super(); // calling parent class constructor
        console.log('Cons Called...',this);
        this.firstName = '';
        this.lastName = '';
        this.message = '';
        this.state = {msg:this.message};
    }
    takeFirstName(event){
        this.firstName = event.target.value;
        console.log('First Name ', this.firstName);
    }
    takeLastName(evt){
        this.lastName = evt.target.value;
        console.log('Last Name ', evt.target.value);
    }
    makeFullName(e){
       let fullName =  this.firstName + this.lastName;
       this.message = `Welcome ${fullName}`;
       this.setState({msg:this.message});
       console.log('Full Name is ',this.message);
    }
    render(){
        console.log('Render Called...');
        return (
            <div className = 'container'>
                <Title/>

                <Input  takeinput={this.takeFirstName.bind(this)} title ='First Name'/>
                <Input takeinput={this.takeLastName.bind(this)} title = 'Last Name'/>
                <br/>
                <Operations opr= {this.makeFullName.bind(this)} styling='btn btn-primary me-2' label="Greet"/>
                <Operations styling='btn btn-secondary' label="Clear All"/>
                <Message message = {this.state.msg} />
            </div>
        )
    }
}
export default Greet;

/*
const  Greet=()=> {


    return (
        <div className = 'container'>
            <Title/>

            <Input title ='First Name'/>
            <Input title = 'Last Name'/>
            <br/>
            <Operations styling='btn btn-primary me-2' label="Greet"/>
            <Operations styling='btn btn-secondary' label="Clear All"/>
        </div>
    )
}
export default Greet;
*/