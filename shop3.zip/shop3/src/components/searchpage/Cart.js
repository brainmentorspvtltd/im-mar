import React, { useState } from 'react'
import { actionCreator } from '../../helpers/actioncreator';
import {ItemContext} from '../../utils/context';
import {store} from '../../models/store';
export const  Cart=(props)=> {
    // useState({x:10, y:20,z:[{},{}]})
    const [cartValue , setCart] =useState(false);
    const toggleCart=()=>{
        //cartValue = true; // Mutate
        setCart(!cartValue) ; // Immutable
    }

    return (
        <>
        <button className='btn btn-warning' onClick={()=>{
            let actionObject =  actionCreator('ADD',!cartValue?1:-1);
            store.dispatch(actionObject);
            toggleCart();}
        }>
{cartValue?'Remove From Cart':'Add to Cart'}</button>
        </>
    );

    /*
    return (
        <>
        <ItemContext.Consumer>
            {
                (context)=><button className='btn btn-warning' onClick={()=>{
                    context.updateTotal(!cartValue?1:-1);
                    toggleCart();

                }}>{cartValue?'Remove From Cart':'Add to Cart'}</button>
            }
        </ItemContext.Consumer>

        </>
    )*/
}
