import React, { useEffect } from 'react'

export const  Norecordfound=(props) =>{

    useEffect(()=>{
        console.log("Component Did Mount Happens....");
        //console.log('Did Update Call');
        return function(){
            console.log("Un Mount Call........");
        }
    },[])
    console.log("Render......");
    return (
        <>
           <h3 className = 'alert-danger'>No Record Found</h3>
        </>
    )
}


/*
export class  Norecordfound extends React.PureComponent {
    constructor(){
        super();
    }
    componentDidMount(){
        // object fill
        console.log('Did Mount Call of No Record Found...');
    }
    componentWillUnmount(){
        // object null
        // clean up code
        console.log('Bye Bye...');
    }
    render(){
    return (
        <>
          <h3 className = 'alert-danger'>No Record Found</h3>
        </>
    )
    }
}
*/
