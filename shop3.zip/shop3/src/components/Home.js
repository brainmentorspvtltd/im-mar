import React from 'react'

export const  Home=(props)=> {


    return (
        <>
                <h1 className='alert-success'>Welcome to the Home Page</h1>
        </>
    )
}
