export const CONFIG ={
    ITEMS_URL:'https://raw.githubusercontent.com/brainmentorspvtltd/myserverdata/master/mobiles.json'
}