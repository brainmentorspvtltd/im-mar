export const actionCreator= (actionName, currentValue)=>{
    return {
        type:actionName,
        payload:{
            currentValue:currentValue
        }
    }
}