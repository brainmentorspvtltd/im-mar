import React from 'react'
import {ItemContext} from '../../utils/context';
export const  Carttotal=(props) =>{


    return (
        <>
        <ItemContext.Consumer>
        {
            (context)=><p>Total Items in Cart {context.totalInCart} </p>
        }
        </ItemContext.Consumer>

        </>
    )
}
