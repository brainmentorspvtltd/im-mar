import React from 'react'
import { Cart } from './Cart';

export const  Item=(props)=> {

    const myStyle = {
        width:'100px',
        height:'100px'

    };

    return (
        <div>

           <img alt="Loading..." src={props.item.url} style={myStyle}/>
           {props.item.name}
           {props.item.price}
           <Cart/>
        </div>
    )
}
