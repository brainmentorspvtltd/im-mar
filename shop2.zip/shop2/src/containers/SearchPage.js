import React from 'react';
import { Carttotal } from '../components/searchpage/CartTotal';
import { Itemslist } from '../components/searchpage/ItemsList';
import { Norecordfound } from '../components/searchpage/NoRecordFound';
import { SearchInput } from '../components/searchpage/SearchInput';
import { Title } from '../components/searchpage/Title';
import { fetchItems } from '../utils/ajax';
export class SearchPage //extends Component{
extends React.PureComponent{
//extends React.Component{
    constructor(props){
        super(props); // init of props
        this.searchTxt = '';

        this.state = {items:[]}; // init of state
        console.log('1. Init Setup of Props and State (Constructor)')

        //this.refs.t1.value;
    }

    /*UNSAFE_componentWillMount(){
        console.log("2. Component Will Mount...");

    }*/


    takeSearchInputValue(txtValue){
        this.searchTxt= txtValue;
        //this.setState({...this.state});
        console.log('State Update.... ',this.searchTxt);
    }
    render(){
        console.log("2. Render");
        //{/* <SearchInput val={this.searchTxt} input={(val)=>this.takeSearchInputValue(val)}/> */}
        return(
            <div className = 'container'>
                <Title/>
                <Carttotal/>

                <SearchInput  input={(val)=>this.takeSearchInputValue(val)}/>
                {this.state.items.length===0?<Norecordfound />:<Itemslist items = {this.state.items}/>}

                </div>
        );
    }
    componentDidUpdate(){
        console.log('Did Update Call');
    }
    /*
    shouldComponentUpdate(nextProps, nextStates){
        this.props != nextProps && this.state!=nextState
        if(this.props.x != nextProps.x){
            return true;  // rendering
        }
        else{
            return false; // no rendering
        }
    }*/
    componentDidMount(){
        console.log('3. ComponentDidMount Call');
        const promise = fetchItems();
        promise.then(response=>{
                console.log('Response is ',response.data.mobiles);
                this.setState({items:response.data.mobiles});
            }).catch(err=>{
            console.log('Error is ',err);
        })
        /*promise.then(response=>{
            response.json().then(data=>{
                 console.log('Data is ',data.mobiles);
                 this.setState({items:data.mobiles});
            }).catch(err=>{
                console.log('JSON Parse Error');
            }).catch(err=>{
                console.log('Not Getting the response ',err);
            })
        })*/
    }
}