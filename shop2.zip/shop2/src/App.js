
import { useState } from 'react';
import './App.css';
import { SearchPage } from './containers/SearchPage';
import { ItemContext } from './utils/context';

let total = 0;
const App=()=> {
  console.log('App Render Call Again');

  const [tot, setTotal] =useState(0);
  const updateTotal=(currentPlus)=>{
    total += currentPlus;
    setTotal(total);
    console.log('After Updation in Total ',total);
  }
  return (
    <ItemContext.Provider value={{totalInCart:total, updateTotal:updateTotal}}>
    <SearchPage/>
    </ItemContext.Provider>
  );
}

export default App;
